#include <iostream>
using namespace std;

/****************************************************************
 * Main program for Extra Credit.
 *
 * Author/copyright:  Duncan Buell. All rights reserved.
 * Date: 28 December 2014
 *
 * Revised: Aaron Barge.
 * Date: 7 October 2020.
**/

int main(int argc, char *argv[])
{
  cout << "Hello, world." << endl;
  cout << "My name is Aaron Barge." << endl;

  return 0;
}

